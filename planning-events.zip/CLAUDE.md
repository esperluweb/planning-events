# Planning Events - Extension WordPress

## Vue d'ensemble

**Planning Events** est une extension WordPress légère et moderne pour gérer et afficher un planning d'événements. Développée par EsperluWeb, cette extension permet de créer des événements avec date, heure, lieu et description, puis de les afficher sur le site via un shortcode.

## Informations générales

- **Version :** 1.0.0
- **Auteur :** EsperluWeb (https://esperluweb.com)
- **License :** GPL2
- **Compatibilité :** WordPress 5.0+ (testé jusqu'à 6.8)
- **Text Domain :** planning-events

## Architecture du projet

```
planning-events/
├── planning-events.php          # Fichier principal du plugin
├── readme.txt                   # Documentation WordPress
├── README.md                    # Documentation GitHub
├── includes/                    # Classes PHP principales
│   ├── class-planning-events.php
│   ├── class-planning-events-post-type.php
│   ├── class-planning-events-shortcode.php
│   └── class-planning-events-settings.php
└── assets/                      # Ressources front-end et admin
    ├── css/
    │   └── planning-events.css
    └── js/
        ├── admin.js
        └── planning-events.js
```

## Fonctionnalités principales

### 1. Custom Post Type "planning_event"
- Interface d'administration dédiée avec icône calendrier
- Champs métadonnés personnalisés :
  - Date de début (obligatoire)
  - Date de fin (optionnelle, auto-remplie)
  - Heure de début/fin (optionnelles)
  - Option "Journée entière"
  - Lieu de l'événement
- Validation des données (dates cohérentes, formats corrects)
- Support des miniatures et extraits

### 2. Affichage front-end via shortcode
- **Shortcode principal :** `[planning_events]`
- **Paramètres optionnels :**
  - `limit` : nombre d'événements à afficher (max 100)
  - `order` : ordre de tri (ASC/DESC)
- **Exemple :** `[planning_events limit="5" order="ASC"]`

### 3. Interface d'administration
- Menu dédié "Planning Événements" dans l'admin WordPress
- Page de paramètres pour personnaliser les couleurs :
  - Couleur principale (défaut: #2c3e50)
  - Couleur au survol (défaut: #1a252f)
- Interface utilisateur intuitive avec validation JavaScript

### 4. Design responsive
- Mise en page adaptative (desktop/mobile)
- Animations CSS modernes (survol, transitions)
- Séparation événements à venir/passés avec accordéon
- Variables CSS pour personnalisation facile

## Structure technique

### Classes principales

#### `Planning_Events` (class-planning-events.php:5)
Classe principale gérant l'initialisation du plugin :
- Chargement des scripts CSS/JS admin et public
- Orchestration des autres composants
- Hooks WordPress (admin/public)

#### `Planning_Events_Post_Type` (class-planning-events-post-type.php:5)
Gestion du type de contenu personnalisé :
- Enregistrement du CPT "planning_event"
- Création des meta boxes pour les champs d'événement
- Validation et sauvegarde des métadonnées
- Interface d'administration

#### `Planning_Events_Shortcode` (class-planning-events-shortcode.php:5)
Rendu du shortcode front-end :
- Récupération des événements (à venir/passés)
- Génération du HTML avec validation des données
- Intégration des couleurs personnalisées
- Gestion des accordéons pour événements passés

#### `Planning_Events_Settings` (class-planning-events-settings.php:5)
Page de paramètres :
- Interface de configuration des couleurs
- Validation des paramètres (couleurs hexadécimales)
- Documentation d'utilisation intégrée

### Sécurité et bonnes pratiques

- **Sécurité :** Vérification ABSPATH, nonces, sanitization, échappement des données
- **Permissions :** Contrôle des capacités utilisateur (manage_options, edit_post)
- **Validation :** Dates au format correct, cohérence temporelle
- **Performance :** Chargement conditionnel des assets, meta queries optimisées
- **Standards WordPress :** Hooks, filtres, conventions de nommage

### Scripts et styles

#### CSS (assets/css/planning-events.css)
- Variables CSS pour thématisation
- Design moderne avec ombres et transitions
- Layout flexbox responsive
- Support accordéon pour événements passés

#### JavaScript Admin (assets/js/admin.js)
- Gestion interface d'édition événements
- Toggle champs heure selon option "journée entière"
- Validation formulaire côté client
- Auto-completion date de fin

#### JavaScript Public (assets/js/planning-events.js)
- Animations hover événements
- Fonctionnalités filtrage (préparé pour évolutions futures)

## Utilisation

### Création d'un événement
1. Aller dans **Planning Événements > Ajouter un événement**
2. Remplir titre, description, date/heure, lieu
3. Publier l'événement

### Affichage sur le site
```
[planning_events limit="10" order="ASC"]
```

### Personnalisation
- **Couleurs :** Via Planning Événements > Paramètres
- **CSS :** Override dans le thème ou personnaliseur WordPress
- **Templates :** Modification du rendu dans class-planning-events-shortcode.php

## Points techniques notables

- **Performance :** Limitation à 100 événements max par shortcode
- **Flexibilité :** Support événements multi-jours
- **UX :** Séparation visuelle événements à venir/passés
- **Maintenabilité :** Architecture orientée objet, séparation des préoccupations
- **Extensibilité :** Structure préparée pour ajout de filtres/catégories

## Commandes de développement

Le projet ne contient pas de scripts de build particuliers. Pour le développement local :

```bash
# Tester le plugin
# 1. Copier le dossier dans wp-content/plugins/
# 2. Activer via l'interface WordPress
# 3. Tester les fonctionnalités via l'admin et shortcode

# Débogage
# Activer WP_DEBUG dans wp-config.php pour voir les erreurs éventuelles
```

## État actuel

Le plugin est dans un état stable (v1.0.0) avec toutes les fonctionnalités de base implémentées. Le code respecte les standards WordPress et inclut une gestion d'erreurs robuste.